module.exports = {
    // itemName (klein) → roleId
    vip: '123456789012345678',         // Beispiel: VIP
    premium: '234567890123456789'     // Beispiel: Premium
};
