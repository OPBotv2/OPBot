function toggleNav() {
    const nav = document.getElementById('nav-links');
    nav.classList.toggle('show');
  }
  