const db = require('./mysql');
const log = require('../utils/log');

module.exports = async function setupDatabase() {
    await db.query(`
        CREATE TABLE IF NOT EXISTS users (
            user_id VARCHAR(32) PRIMARY KEY,
            balance BIGINT DEFAULT 0,
            last_daily BIGINT DEFAULT 0
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) UNIQUE NOT NULL,
            price INT NOT NULL,
            type VARCHAR(20) DEFAULT 'consumable'
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS inventory (
            user_id VARCHAR(32),
            item_id INT,
            quantity INT DEFAULT 1,
            PRIMARY KEY (user_id, item_id),
            FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            type VARCHAR(20),
            details TEXT,
            timestamp BIGINT
        )
    `);
    
    await db.query(`
        CREATE TABLE IF NOT EXISTS changelogs (
          id INT AUTO_INCREMENT PRIMARY KEY,
          version VARCHAR(20) NOT NULL,
          date DATE NOT NULL,
          entries TEXT NOT NULL,
          guild_id VARCHAR(32) NOT NULL,
          UNIQUE KEY version_guild (version, guild_id)
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS changelog_channels (
            guild_id VARCHAR(32) PRIMARY KEY,
            channel_id VARCHAR(32) NOT NULL
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS guild_settings (
          guild_id VARCHAR(32) NOT NULL,
          setting_key VARCHAR(64) NOT NULL,
          setting_value TEXT,
          PRIMARY KEY (guild_id, setting_key)
        )
    `);
    
    log.info('✅ Datenbanktabellen wurden überprüft/erstellt.');
    await log.discord(`✅ Datenbanktabellen wurden überprüft/erstellt.`, 'info');
};
